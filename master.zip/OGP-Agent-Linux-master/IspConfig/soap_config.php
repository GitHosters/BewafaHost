<?php
$username = 'admin';
$password = 'admin';

$soap_location = 'http://127.0.0.1:8080/remote/index.php';
$soap_uri = 'http://127.0.0.1:8080/remote/';
?>
